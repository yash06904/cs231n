import numpy as np
from random import shuffle
from past.builtins import xrange

def softmax_loss_naive(W, X, y, reg):
    """
    Softmax loss function, naive implementation (with loops)

    Inputs have dimension D, there are C classes, and we operate on minibatches
    of N examples.

    Inputs:
    - W: A numpy array of shape (D, C) containing weights.
    - X: A numpy array of shape (N, D) containing a minibatch of data.
    - y: A numpy array of shape (N,) containing training labels; y[i] = c means
     that X[i] has label c, where 0 <= c < C.
    - reg: (float) regularization strengthd

    Returns a tuple of:
    - loss as single float
    - gradient with respect to weights W; an array of same shape as W
   """
  # Initialize the loss and gradient to zero.
    num_train = X.shape[0]
    num_class = W.shape[1]
    loss = 0.0
    dW = np.zeros_like(W)
    for train_id in range(num_train):
        score = np.dot(X[train_id],W)
        score = score - np.max(score)
        score = np.exp(score)
        loss += -np.log(score[y[train_id]]/np.sum(score))
        
    loss /= num_train     
    loss += reg*np.sum(W*W)    
    
    for train_id in range(num_train):
        for class_id in range(num_class):
            score = np.dot(X[train_id],W)
            score = score - np.max(score)
            score = np.exp(score)
            if (y[train_id] == class_id):
                dW[:,class_id] +=   -X[train_id]*[1 - score[y[train_id]]/np.sum(score)]
            else:
                dW[:,class_id] +=   -X[train_id]* -score[class_id]/(np.sum(score))
                
            
    dW /= num_train
    dW += reg*W
  #############################################################################
  # TODO: Compute the softmax loss and its gradient using explicit loops.     #
  # Store the loss in loss and the gradient in dW. If you are not careful     #
  # here, it is easy to run into numeric instability. Don't forget the        #
  # regularization!                                                           #
  #############################################################################
    pass
  #############################################################################
  #                          END OF YOUR CODE                                 #
  #############################################################################

    return loss, dW


def softmax_loss_vectorized(W, X, y, reg):
    """
    Softmax loss function, vectorized version.

    Inputs and outputs are the same as softmax_loss_naive.
    """
    num_train = X.shape[0]
    num_class = W.shape[1]
  # Initialize the loss and gradient to zero.
    loss = 0.0
    dW = np.zeros_like(W)
    score = np.dot(X,W)
    scores_max = np.reshape(np.max(score,axis = 1),(score.shape[0],1))
    scores_exp = np.exp(score - scores_max)
    scores_sum = np.sum(scores_exp,axis = 1)
    scores_norm = scores_exp[np.arange(num_train),y]/scores_sum
    loss = -np.mean(np.log(scores_norm))
    loss += reg * np.sum(W*W)
    
  # gradient  
    scores_normalized = scores_exp/np.reshape(scores_sum,(scores_exp.shape[0],1))
    tmp_matrix = np.zeros((num_train,num_class))
    tmp_matrix[np.arange(num_train),y] = 1
    S_mat = tmp_matrix - scores_normalized
    dW = -np.dot(X.T,S_mat)
    dW /= num_train
    
    dW += reg*W
    
  #############################################################################
  # TODO: Compute the softmax loss and its gradient using no explicit loops.  #
  # Store the loss in loss and the gradient in dW. If you are not careful     #
  # here, it is easy to run into numeric instability. Don't forget the        #
  # regularization!                                                           #
  #############################################################################
    pass
  #############################################################################
  #                          END OF YOUR CODE                                 #
  #############################################################################

    return loss, dW

