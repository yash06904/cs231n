wget "http://cs231n.stanford.edu/squeezenet_tf.zip"
unzip squeezenet_tf.zip
rm squeezenet_tf.zip
